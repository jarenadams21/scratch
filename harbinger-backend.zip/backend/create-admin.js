#!/usr/bin/env node
import readline from 'readline';
import bcrypt from 'bcryptjs';
import { DynamoDBClient } from '@aws-sdk/client-dynamodb';
import { DynamoDBDocumentClient, PutCommand, GetCommand } from '@aws-sdk/lib-dynamodb';
import { readFileSync } from 'fs';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';

const __dirname = dirname(fileURLToPath(import.meta.url));
const flags = JSON.parse(readFileSync(join(__dirname, '../config/flags.json'), 'utf8'));

const region = process.env.AWS_REGION || flags.database.region;
const table  = process.env.DYNAMODB_TABLE || flags.database.table_name;

const client = DynamoDBDocumentClient.from(new DynamoDBClient({ region }));

const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
const ask = (q) => new Promise(res => rl.question(q, res));

async function askPassword(prompt) {
  process.stdout.write(prompt);
  process.stdin.setRawMode?.(true);
  return new Promise(res => {
    let val = '';
    process.stdin.resume();
    process.stdin.setEncoding('utf8');
    const handler = (ch) => {
      if (ch === '\n' || ch === '\r' || ch === '') {
        process.stdin.setRawMode?.(false);
        process.stdin.removeListener('data', handler);
        process.stdout.write('\n');
        res(val);
      } else if (ch === '') {
        val = val.slice(0, -1);
      } else {
        val += ch;
        process.stdout.write('*');
      }
    };
    process.stdin.on('data', handler);
  });
}

async function run() {
  console.log('\nHarbinger — Admin Account Setup');
  console.log(`Table: ${table}  Region: ${region}\n`);

  const email = (await ask('Email: ')).trim().toLowerCase();
  if (!email.includes('@')) { console.error('Invalid email.'); process.exit(1); }

  const existing = await client.send(new GetCommand({
    TableName: table,
    Key: { pk: `USER#${email}`, sk: 'PROFILE' }
  })).catch(() => null);

  if (existing?.Item) {
    const overwrite = (await ask(`Account already exists for ${email}. Overwrite? (y/N): `)).trim();
    if (overwrite.toLowerCase() !== 'y') { console.log('Cancelled.'); process.exit(0); }
  }

  const pass    = await askPassword('Password (min 8 chars): ');
  const confirm = await askPassword('Confirm password: ');

  if (pass.length < 8)   { console.error('Password too short.'); process.exit(1); }
  if (pass !== confirm)  { console.error('Passwords do not match.'); process.exit(1); }

  rl.close();

  const passwordHash = await bcrypt.hash(pass, 10);

  await client.send(new PutCommand({
    TableName: table,
    Item: {
      pk: `USER#${email}`,
      sk: 'PROFILE',
      email,
      passwordHash,
      role: 'admin',
      createdAt: new Date().toISOString(),
    }
  }));

  console.log(`\nAdmin account created: ${email}`);
  console.log('You can now log in at your Harbinger URL.');
}

run().catch(err => { console.error(err.message); process.exit(1); });
